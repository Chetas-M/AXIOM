"""Lightweight signal review dashboard."""
