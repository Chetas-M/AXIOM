"""Data ingestion pipelines."""
