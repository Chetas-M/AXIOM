# TODO: Implement bot commands
