# TODO: Implement ingestion pipeline
